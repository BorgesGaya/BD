package br.edu.ifrs.riogrande.tads.cobaia.domain.livro;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

// Data Transfer Object (intercâmbio), ViewModel
// Modelo tanto para o tráfego, quanto validação
@Data
@Builder
@AllArgsConstructor
public class LivroDTO {

  private Long id;

  @JsonProperty("tituloCompleto") // body/endpoint
  // @jakarta.validation.constraints.*
  @NotNull(message = "O titulo é obrigatório")
  @NotBlank(message = "O titulo não pode estar em branco")
  private String titulo;

  private String autor;
  private String genero;

}
