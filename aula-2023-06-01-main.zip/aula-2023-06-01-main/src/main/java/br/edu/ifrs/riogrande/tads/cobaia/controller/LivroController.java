package br.edu.ifrs.riogrande.tads.cobaia.controller;

import static java.util.Objects.requireNonNull;

import java.net.URI;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriBuilder;

import br.edu.ifrs.riogrande.tads.cobaia.domain.livro.LivroDTO;
import br.edu.ifrs.riogrande.tads.cobaia.domain.livro.LivroService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/livro/api/livros") // resource (recurso) => plural
public class LivroController {
  
  private final LivroService livroService;
  
  @DeleteMapping("/{id}")
  public ResponseEntity<?> excluir(@PathVariable Long id) {
   
    try {
      livroService.excluir(id);
      return ResponseEntity.ok().build(); // 200
    } catch (IllegalStateException e) {
      return ResponseEntity.notFound().build();
    }
    
  }

  @PostMapping
  public ResponseEntity<?> novoLivro(@Valid @RequestBody LivroDTO livro) {

    livroService.salvar(Objects.requireNonNull(livro, "Livro é null"));

    // http://localhost:9090/api/v1/livros/{id}
    URI location = ServletUriComponentsBuilder
      .fromCurrentRequest()
      .path("/{id}")
      .buildAndExpand(livro.getId())
      .toUri();

    return ResponseEntity.ok(location); // 200 
    //return ResponseEntity.created(location).build(); // 201 CREATED Location: URL do recurso criado
  }


  @GetMapping
  public List<LivroDTO> getLivros() {
    return livroService.getLivrosOrderByTitulo();
  }

  @PutMapping //api/v1/alunos
  public ResponseEntity<List<Long>> atualizar(@RequestBody List<LivroDTO> dtos) {

    List<Long> idsFalharam = livroService.atualizarEmLote(dtos);

    return ResponseEntity.ok().body(idsFalharam);
  }

  @PutMapping("/{id}") //alunos/1
  public ResponseEntity<?> atualizar(
    @PathVariable("id") Long id,
    @RequestBody LivroDTO dto) {

    livroService.atualizar(id, dto);

    return ResponseEntity.ok().build();
  }

  @GetMapping("/{id}") // ex.: /alunos?id=1 (? query param) ou /alunos/1 (recurso com uma identidade)
  public ResponseEntity<LivroDTO> getLivro(@PathVariable("id") Long id) {

    Optional<LivroDTO> livro = livroService.findById(
      requireNonNull(id, "O id é obrigatório"));

    if (livro.isPresent()) {
      return ResponseEntity.ok(livro.get()); // 200 {"nome": "Marcio"}
      // return ResponseEntity.ok().body(aluno.get());
    } else {
      // return ResponseEntity.noContent().build(); // 204
      // return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
      // return ResponseEntity.status(404).build();
      return ResponseEntity.notFound().build();
    }
  }
}
