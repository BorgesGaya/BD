package br.edu.ifrs.riogrande.tads.cobaia.domain.livro;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

public interface LivroRepository // <TipoEntidade, TipoId>
                extends Repository<Livro, Long> {

  List<Livro> findAll();

  Optional<Livro> findById(Long id);

  void delete(Livro livro);

  Livro save(Livro a);
  
}

