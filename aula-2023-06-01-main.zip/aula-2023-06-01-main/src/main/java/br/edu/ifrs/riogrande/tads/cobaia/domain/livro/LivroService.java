package br.edu.ifrs.riogrande.tads.cobaia.domain.livro;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class LivroService {

  private final LivroRepository livroRepository;

  private LivroDTO toDTO(Livro a) {
    return LivroDTO.builder()
          .id(a.getId())
          .titulo(a.getTitulo())
          .autor(a.getAutor())
          .genero(a.getGenero())
          .build();
  }

  @Deprecated(since = "jun/2023", forRemoval = true)
  public List<LivroDTO> getLivros() {
    final boolean isParallel = false;
    return StreamSupport
      .stream(livroRepository.findAll().spliterator(), isParallel)
        .map(this::toDTO)
      .toList();
  }

  public List<LivroDTO> getLivrosOrderByTitulo() {
    return livroRepository.findAll().stream()
        .map(a -> LivroDTO.builder()
        .id(a.getId())
        .titulo(a.getTitulo())
        .autor(a.getAutor())
        .genero(a.getGenero())
        .build())
        .toList(); 
  }

  public Optional<LivroDTO> findById(@NonNull Long id) {
    return livroRepository.findById(id)
      .flatMap(livro -> Optional.of(toDTO(livro)));
  }

  // garantia de não-nulidade
  public void salvar(@NonNull LivroDTO livroDTO) {
    
    // Aluno a = objectMapper.readValue(objectMapper.writeValueAsString(alunoDTO), Aluno.class);
    // conversão?
    Livro livro = Livro.builder()
      .titulo(livroDTO.getTitulo())
      .autor(livroDTO.getAutor())
      .genero(livroDTO.getGenero())
      .build();

    livroRepository.save(livro);
  }
  

  public void excluir(Long id) {

    Livro livro = livroRepository.findById(id)
      .orElseThrow(() -> new IllegalStateException("Livro não existe"));

    livroRepository.delete(livro);
  }

  @PostConstruct
  void popularBanco() {
    System.out.println("Populando o mochinho ...");

    Livro a = new Livro();
    a.setTitulo("Programação para amadores");
    a.setAutor("Marcio");
    a.setGenero("Escolar");

    a = livroRepository.save(a);

    System.out.println(livroRepository.getClass());

    System.out.println("Livro salvo " + a.getId());

    System.out.println(livroRepository.findAll());
  }

	public void atualizar(Long id, LivroDTO dto) {

    Livro livro = livroRepository.findById(id)
      .orElseThrow(() -> new IllegalStateException("Livro não encontrado"));

    livro.setTitulo(dto.getTitulo());
    livro.setAutor(dto.getAutor());
    livro.setGenero(dto.getGenero());

    livroRepository.save(livro);

	}

  public List<Long> atualizarEmLote(List<LivroDTO> dtos) {
    List<Long> ids = new ArrayList<>();

    dtos.forEach(dto -> {
      try {
        atualizar(dto.getId(), dto);
      } catch (IllegalStateException e) {
        ids.add(dto.getId());
      }
    });

    return ids;
  }
}
