package br.edu.ifrs.riogrande.tads.cobaia.domain.livro;

import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "livros")
// sem visibilidade: privado do pacote
public class Livro { // Java Bean
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY) // sequencial
  private Long id;

  @Column(length = 50, nullable = false, name = "db_rs5_nome")
  @JsonProperty("tituloCompleto") // body/endpoint
  // @jakarta.validation.constraints.*
  @NotNull(message = "O titulo é obrigatório")
  @NotBlank(message = "O titulo não pode estar em branco")
  private String titulo;

  @Column(length = 100, nullable = false)
  private String autor;

  @Column(length = 100, nullable = false)
  private String genero;

}
