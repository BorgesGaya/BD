# MVC

Model (modelo)
View (visão/apresentação)
Controller (controlador)

Existem outros:

MVVM: Model View ViewModel
MVP: Model View Presenter